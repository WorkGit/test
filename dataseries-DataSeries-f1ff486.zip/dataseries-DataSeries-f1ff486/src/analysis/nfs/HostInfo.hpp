/*
   (c) Copyright 2003-2008, Hewlett-Packard Development Company, LP

   See the file named COPYING for license details
*/

namespace NFSDSAnalysisMod {
    RowAnalysisModule *newHostInfo(DataSeriesModule &prev, char *arg);
}
