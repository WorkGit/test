#include <parallel/losertree.h>

int main() {
    return 0;
}
