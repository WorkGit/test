#ifndef BIGTOP__H
#define BIGTOP__H
#include <a.h>

class BigTop {
    Actor *forActor;

public:
    BigTop( Actor *a);
    void show();
};
#endif
